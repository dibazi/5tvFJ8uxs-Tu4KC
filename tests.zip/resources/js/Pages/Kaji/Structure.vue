<template>
    <app-layout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Structure
            </h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                    <div class="flex justify-center items-center min-h-screen bg-white">
                        <div class="flex-1 max-w-5x1 p-16">
                            <div class="grid grid-cols-2 grid-rows-3 gap-4 grid-flow-dense">

                                <div class="container mx-auto p-4 pr-6 bg-white border-1-8 border-transparent border-4 border-black rounded-md shawdow-md space-y-2">
                                    <h2 class="text-lg font-semibold leading-6">Home renovation</h2>
                                    <p class="text-gray-600">A place to keep track of all renovation going around the house</p>
                                </div>

                                <div class="p-4 pr-6 bg-white border-1-8 border-transparent border-4 border-black rounded-md shawdow-md space-y-2">
                                    <h2 class="text-lg font-semibold leading-6">Home renovation</h2>
                                    <p class="text-gray-600">A place to keep track of all renovation going around the house</p>
                                </div>

                                 <div class="p-4 pr-6 bg-white border-1-8 border-transparent border-4 border-black rounded-md shawdow-md space-y-2">
                                    <h2 class="text-lg font-semibold leading-6">Home renovation</h2>
                                    <p class="text-gray-600">A place to keep track of all renovation going around the house</p>
                                </div>

                                 <div class="row-span-full p-4 pl-6 bg-white border-1-8 border-2 border-blue-500 rounded-md shawdow-md space-y-2">
                                    <h2 class="text-lg font-semibold leading-6">Description</h2>
                                    <p class="text-gray-600">
What is Lorem Ipsum?
Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, 
but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset 
sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem 
Ipsum.


</p>
                                </div>
                                
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </app-layout>
</template>

<script>
    import AppLayout from '@/Layouts/AppLayout'
    import Add from './add.vue'

    export default {
        components: {
            AppLayout,
            Add

        },
    }
</script>
