<template>
    <div class="todolistContainer">
        <div class="heading">
            <h2 id="title">Todo list</h2>
            <add-item-form
            v-on:reloadlist="getList()"
            />
        </div>

    </div>
</template>

<script>
import AddItemForm from './addItemForm.vue'

    export default {

        components:{
                AddItemForm,
        },

    }
</script>

<style scoped>
.todolistContainer{
    width: 350;
    margin: auto;
}
.heading{
    background: #e6e6e6;
    padding: 10px;
}
#title{
    text-align: center;
}
</style>