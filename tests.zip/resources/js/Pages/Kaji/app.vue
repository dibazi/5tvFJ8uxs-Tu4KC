<template>
    <div class="todolistContainer">
        <div class="heading">
            <h2 id="title">Todo list</h2>
            <add-item-form
            v-on:reloadlist="getList()"
            />
        </div>
        <list-view :items="items"
        v-on:reloadlist="getList()"
        />
    </div>
</template>

<script>
import AddItemForm from './addItemForm.vue'
import ListView from './listView.vue'

    export default {

        components:{
                AddItemForm,
                ListView
        },
        data: function () {
            return{
                items: []
            }
        },
        methods: {
            getList () {
                axios.get('api/item').then(response => {
                    this.items =response.data
                }).catch(error => {
                    console.log(error);
                })
            }
        },
        created(){
            this.getList();
        }

    }
</script>

<style scoped>
.todolistContainer{
    width: 350;
    margin: auto;
}
.heading{
    background: #e6e6e6;
    padding: 10px;
}
#title{
    text-align: center;
}
</style>