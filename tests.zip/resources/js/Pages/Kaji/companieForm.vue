<template>

    <app-layout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Formulaire pour companie
            </h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

                    <div class="antialiased bg-gray-100">

                        <div class="flex w-full min-h-screen justify-center items-center">
                            <div class="grid grid-cols-1 md:grid-cols-2 flex flex-col md:flex-row md:space-x-6 md:space-y-0 space-y-6 bg-blue-700 w-full max-w-4x1 p-8 rounded-xl shadow-lg text-white">
                                <div class="flex flex-col justify-between">
                                    <div>
                                        <H1 class="font-bold text-4xl tracking-wide">Contact Us</H1>
                                        <p class="pt-2 text-blue-100 text-sm"></p>
                                    </div>

                                    <div class="flex flex-col space-y-4">
                                        <div class="inline-flex space-x-2 item-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" 
                                            class="bi bi-telephone" viewBox="0 0 16 16">
                                            <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 
                                            17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.
                                            678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.
                                            459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.
                                            511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 
                                            .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 
                                            1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 
                                            1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
                                            </svg>
                                            <span>+(27)780109045</span>
                                        </div>

                                        <div class="inline-flex space-x-2 item-center">
                                            <h3>Adress mail:</h3>
                                            <span>E-mail</span>
                                        </div>

                                        <div class="inline-flex space-x-2 item-center">
                                            <h3>Adress:</h3>
                                            <span>Bryanston, olivedale</span>
                                        </div>

                                    </div>
                
                                    <div class="flex space-x-4 text-lg">
                                    <a href=""><span>Facebook</span></a>
                                    <a href=""><span>Instagram</span></a>
                                    <a href=""><span>Twitter</span></a>

                                    </div>
                                </div>
                                <div>
                                    <div class="bg-white rounded-xl shawdow-lg p-8 text-gray-600">

                                        <div><label for="" class="text-blue-700">Cree anonce comme particulier, click <a class="text-green-500" href="/p/f">ici</a>.</label></div>

                                        <form @submit.prevent="addItem()" action="" class="flex flex-col space-y-4">
                                            <div><label for="" class="text-blue-700">Information sur la companie</label></div>
                                            <div>
                                                <label for="" class="text-sm">Nom </label>

                                                <input v-model="job.companyName" type="text" required placeholder="Nom de la companie. Exp Kaji Limited" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            
                                            <div>
                                                <label for="" class="text-sm">Pays </label>

                                                <input v-model="job.country" required type="text" placeholder="Pays dans lequel la companie est etablie. Exp. RD Congo" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Ville </label>

                                                <input v-model="job.city" required type="text" placeholder="Ville dans laquel la companie est etablie. Exp. Lubumbashi" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>
                                            
                                             <div>
                                                <label for="" class="text-sm">Adress </label>

                                                <input v-model="job.adress" required type="text" placeholder="Adress de la companie" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>
                                                                                        
                                             <div>
                                                <label for="" class="text-sm">Telephone</label>

                                                <input v-model="job.companyTel" required type="text" placeholder="Numeraux telephone de la companie Exp. 0112346756" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div><label for="" class="text-blue-700">Information sur le poste</label></div>

                                             <div>
                                                <label for="" class="text-sm">Domaine/Categorie</label>

                                                <input v-model="job.domaine" required type="text" placeholder="Ex. construction" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>
                                          
                                             <div>
                                                <label for="" class="text-sm">Nom du post</label>

                                                <input v-model="job.position" required type="text" placeholder="Ex. Chef de chantier" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Salaire </label>

                                                <select name="currency" id="" required v-model="job.currency">
                                                    <option value="">Choisir monaie</option>
                                                    <option value="FC">Franc congolais</option>
                                                    <option value="$">Dollor americain</option>
                                                </select>

                                                <input v-model="job.salary" required type="text" placeholder="Salaire du post Exp. 200000" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Description</label>

                                                <textarea v-model="job.description" required name="" id="" rows="10" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300" placeholder="Description du post, responsabilite..."></textarea>
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Date final</label>

                                                <input v-model="job.dateFinal" required type="text" placeholder="Date final depot de candidature Exp. 21/02/2021" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Adress mail pour cv</label>

                                                <input v-model="job.cvemail" required type="email" placeholder="Adress mail ou envoyer les cv Exp. adressecv@kaji.com" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <button @click="redirect" class="inline-block self-end bg-blue-700 text-white font rounded-lg px-6 py-2 uppercase ">Publie</button>

                                        </form>

                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        </div>     

                </div>
            </div>
        </div>
    </app-layout>
</template>
<script>
    import AppLayout from '@/Layouts/AppLayout'
    import Add from './add.vue'
    import axios from 'axios'

    export default {
        components: {
            AppLayout,
            Add

        },
                data: function() {
            return{
                job:{
                   companyName:"",
                   country:"",
                   city:"",
                   adress:"",
                   companyTel:"",
                   domaine:"",
                   position:"",
                   salary:"",
                   currency:"",
                   dateFinal:"",
                   description:""
                   
                    
                }
            }
        },
            methods:{
            addItem(){
                if(this.job.companyName == ''){
                    return;
                }
                axios.post('/api/c', {
                    job: this.job
                }).then(response =>{
                    if(response.status == 201){
                        this.job.companyName = "";
                        this.job.country = "";
                        this.job.city = "";
                        this.job.adress = "";
                        this.job.companyTel = "";
                        this.job.domaine = "";
                        this.job.position = "";
                        this.job.currency = "";
                        this.job.salary = "";
                        this.job.description = "";
                        this.job.dateFinal = "";
                        this.job.cvemail = "";
                        this.$router.push('companies')
                        this.$emit('itemchanged');     

                    }
                }).catch( error =>{
                    console.log(error);
                })
            },
            redirect(){
                this.$router.push({name:'/dashboard'})
            }
        }
    }
</script>
