<template>

    <app-layout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Form particulier
            </h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

                    <div class="antialiased bg-gray-100">

                        <div class="flex w-full min-h-screen justify-center items-center">
                            <div class="grid grid-cols-1 md:grid-cols-2 flex flex-col md:flex-row md:space-x-6 md:space-y-0 space-y-6 bg-blue-700 w-full max-w-4x1 p-8 rounded-xl shadow-lg text-white">
                                <div class="flex flex-col justify-between">
                                    <div>
                                        <H1 class="font-bold text-4xl tracking-wide">Contact Us</H1>
                                        <p class="pt-2 text-blue-100 text-sm"></p>
                                    </div>

                                    <div class="flex flex-col space-y-4">
                                        <div class="inline-flex space-x-2 item-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" 
                                            class="bi bi-telephone" viewBox="0 0 16 16">
                                            <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 
                                            17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.
                                            678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.
                                            459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.
                                            511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 
                                            .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 
                                            1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 
                                            1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
                                            </svg>
                                            <span>+(27)780109045</span>
                                        </div>

                                        <div class="inline-flex space-x-2 item-center">
                                            <h3>Adress mail:</h3>
                                            <span>E-mail</span>
                                        </div>

                                        <div class="inline-flex space-x-2 item-center">
                                            <h3>Adress:</h3>
                                            <span>Bryanston, olivedale</span>
                                        </div>

                                    </div>
                
                                    <div class="flex space-x-4 text-lg">
                                    <a href=""><span>Facebook</span></a>
                                    <a href=""><span>Instagram</span></a>
                                    <a href=""><span>Twitter</span></a>

                                    </div>
                                    
                                </div>
                                <div>
                                    <div class="bg-white rounded-xl shawdow-lg p-8 text-gray-600">

                                    <div><label for="" class="text-blue-700">Cree anonce comme companie, click <a class="text-green-500" href="/form">ici</a>.</label></div>


                                        <form @submit="addItem()" action="" class="flex flex-col space-y-4">
                                            <div><label for="" class="text-blue-700">Information sur le Particulier</label></div>
                                            <div>
                                                <label for="" class="text-sm">Adress mail </label>

                                                <input v-model="part.email" type="email" placeholder="Votre adress mail" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Pays </label>

                                                <input v-model="part.pays" type="text" placeholder="Pays ou le post est disponible" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Ville </label>

                                                <input v-model="part.ville" type="text" placeholder="Ville ou le post est disponible" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>
                                                                                          
                                            <div><label for="" class="text-blue-700">Information sur le poste</label></div>

                                             <div>
                                                <label for="" class="text-sm">Domaine/Categorie</label>

                                                <input v-model="part.domaine" type="text" placeholder="Ex. construction" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>
                                          
                                             <div>
                                                <label for="" class="text-sm">Nom du post</label>

                                                <input v-model="part.position" type="text" placeholder="Ex. Chef de chantier" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>
                                            <div>
                                                <label for="" class="text-sm">Salaire </label>

                                                <select name="currency" id="" v-model="part.currency">
                                                    <option value="">Choisir monaie</option>
                                                    <option value="FC">Franc congolais</option>
                                                    <option value="$">Dollor americain</option>
                                                </select>

                                                <input v-model="part.salaire" type="text" placeholder="Salaire du post Exp. 200000" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Description</label>

                                                <textarea v-model="part.description" name="" id="" cols="30" rows="30" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300" placeholder="Description du post, responsabilite..."></textarea>
                                            </div>
                                            
                                            <div>
                                                <label for="" class="text-sm">Date final</label>

                                                <input v-model="part.dateFinal" type="text" placeholder="Date final depot de candidature Exp. 21/02/2021" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <div>
                                                <label for="" class="text-sm">Adress mail pour cv</label>

                                                <input v-model="part.cvemail" type="email" placeholder="Adress mail ou envoyer les cv" class="ring ring-gray-300 w-full rounded-md px-4 py-2 outline-none focus:ring-2 focus:ring-teal-300">
                                            </div>

                                            <button @click="redirect" class="inline-block self-end bg-blue-700 text-white font rounded-lg px-6 py-2 uppercase ">Publie</button>

                                        </form>

                                    </div>

                                </div>
                            </div>
                        </div>
                        
                        </div>     

                </div>
            </div>
        </div>
    </app-layout>
</template>
<script>
    import AppLayout from '@/Layouts/AppLayout'
    import Add from './add.vue'
    import axios from 'axios'

    export default {
        components: {
            AppLayout,
            Add

        },
                data: function() {
            return{
                part:{
                   email:"",
                   pays:"",
                   ville:"",
                   domaine:"",
                   position:"",
                   currency:"",
                   salary:"",
                   description:"",
                   dateFinal:"",
                   cvemail:"",
                    
                }
            }
        },

            methods:{
            addItem(){
                if(this.part.email == ''){
                    return;
                }
                axios.post('/api/p', {
                    part: this.part
                }).then(response =>{
                    if(response.status == 201){
                        this.part.email = "";
                        this.part.pays = "";
                        this.part.ville = "";
                        this.part.domaine = "";
                        this.part.position = "";
                        this.part.currency = "";
                        this.part.salary = "";
                        this.part.description = "";
                        this.part.dateFinal = "";
                        this.part.cvemail = "";
                        this.$emit('itemchanged');
                        
                        

                    }
                }).catch( error =>{
                    console.log(error);
                })
            },
            redirect(){
                this.$router.push({name:'/dashboard'})
            }
        }
    }
</script>
